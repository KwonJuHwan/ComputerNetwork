void arqTimer_startTimer();
void arqTimer_stopTimer();
uint8_t arqTimer_getTimerStatus();