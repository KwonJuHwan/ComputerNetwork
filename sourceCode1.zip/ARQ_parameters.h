#define DBGMSG_ARQ                      0 //debug print control
#define ARQ_MAXRETRANSMISSION           10
#define ARQTIMER_MAXWAITTIME            5
#define ARQTIMER_MINWAITTIME            2